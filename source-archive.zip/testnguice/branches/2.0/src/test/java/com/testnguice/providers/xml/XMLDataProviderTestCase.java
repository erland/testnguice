/*
 *    Copyright 2008-2009 Simone Tripodi
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package com.testnguice.providers.xml;

import java.util.Date;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
*
* @author Simone Tripodi
* @version $Id: XMLDataProviderTestCase.java 149 2009-11-24 08:23:46Z simone.tripodi $
*/
public final class XMLDataProviderTestCase {

    @BeforeTest
    public void setUp() {
        DateConverter dateConverter = new DateConverter();
        dateConverter.setPatterns(new String[] {
                "yyyy",
                "yyyy-MM",
                "yyyy-MM-dd",
                "yyyy-MM-dd'T'HH",
                "yyyy-MM-dd'T'HH:mm",
                "yyyy-MM-dd'T'HH:mm:ss"
        });
        ConvertUtils.register(dateConverter, Date.class);
    }

    @Test(
            dataProvider = XMLDataProvider.DATA_PROVIDER_ID,
            dataProviderClass = XMLDataProvider.class
    )
    public void verifyCorrectTypeConversion(final Date date, final String message, final int integer) {
        assert date != null;
        assert message != null;
        assert integer != 0;
    }

}
