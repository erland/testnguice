/*
 *    Copyright 2008-2010 Simone Tripodi
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package com.googlecode.testnguice.providers.xml;

import org.apache.commons.digester.Rule;
import org.xml.sax.Attributes;

/**
 * The Digester rules that creates an array that represents the test method
 * arguments.
 *
 * @author Simone Tripodi
 * @version $Id: ObjectArrayCreateRule.java 237 2010-06-05 15:10:09Z simone.tripodi $
 */
final class ObjectArrayCreateRule extends Rule {

    /**
     * The test method arguments number.
     */
    private final int size;

    /**
     * The arguments setter reference.
     */
    private final ObjectArraySetArgumentRule argumentRule;

    /**
     * Creates a new {@code ObjectArrayCreateRule}.
     *
     * @param size the test method arguments number.
     * @param argumentRule the arguments setter reference.
     */
    public ObjectArrayCreateRule(int size,
            ObjectArraySetArgumentRule argumentRule) {
        this.size = size;
        this.argumentRule = argumentRule;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void begin(final String namespace, final String name, final Attributes attributes) throws Exception {
        this.digester.push(new Object[this.size]);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void end(String namespace, String name) throws Exception {
        this.digester.pop();
        this.argumentRule.reset();
    }

}
