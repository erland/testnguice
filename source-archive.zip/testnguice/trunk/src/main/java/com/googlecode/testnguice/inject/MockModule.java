/*
 *    Copyright 2008-2010 Simone Tripodi
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package com.googlecode.testnguice.inject;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.mockito.Mockito;

import com.google.inject.AbstractModule;
import com.google.inject.Binder;
import com.google.inject.BindingAnnotation;
import com.google.inject.Inject;
import com.google.inject.binder.AnnotatedBindingBuilder;

/**
 * 
 *
 * @author Simone Tripodi
 * @version $Id: MockModule.java 245 2010-06-29 11:44:24Z simone.tripodi $
 */
final class MockModule extends AbstractModule {

    /**
     * 
     */
    private final Class<?> testClass;

    /**
     * 
     *
     * @param testClass
     */
    public MockModule(final Class<?> testClass) {
        this.testClass = testClass;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void configure() {
        configure(this.testClass, this.binder());
    }

    private static void configure(Class<?> type, Binder binder) {
        if (Object.class == type) {
            return;
        }

        for (Field field : type.getDeclaredFields()) {
            if (field.isAnnotationPresent(Inject.class)) {
                configure(field.getType(), field.getAnnotations(), binder);
            }
        }

        for (Method method : type.getMethods()) {
            if (method.isAnnotationPresent(Inject.class)) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                for (int i = 0; i < parameterTypes.length; i++) {
                    configure(parameterTypes[i], method.getParameterAnnotations()[i], binder);
                }
            }
        }

        configure(type.getSuperclass(), binder);
    }

    private static void configure(Class<?> classToMock, Annotation[] annotations, Binder binder) {
        boolean mock = false;
        Annotation bindingAnnotation = null;

        for (Annotation annotation : annotations) {
            if (Mock.class == annotation.annotationType()) {
                mock = true;
            }
            if (annotation.annotationType().isAnnotationPresent(BindingAnnotation.class)) {
                bindingAnnotation = annotation;
            }
        }

        if (mock) {
            applyBind(classToMock, bindingAnnotation, binder);
        }
    }

    private static <T> void applyBind(Class<T> classToMock, Annotation bindingAnnotation, Binder binder) {
        AnnotatedBindingBuilder<T> builder = binder.bind(classToMock);
        if (bindingAnnotation != null) {
            builder.annotatedWith(bindingAnnotation).toInstance(Mockito.mock(classToMock));
        } else {
            builder.toInstance(Mockito.mock(classToMock));
        }
    }

}
