/*
 *       Copyright (c) 2008 All rights reserved
 *               Asemantics S.r.l
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        Asemantics S.r.l."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Asemantics S.r.l.
 *    the Semantic Web company, Rome, London, Leiden and its contributors.
 *
 * 5. Neither the name of the company nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package com.asemantics.testnguice.providers;

import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.converters.DateConverter;
import org.testng.annotations.DataProvider;

/**
 * A {@link DataProvider} based on CSV data format.
 *
 * @author Simone Tripodi (simone.tripodi)
 * @version $Id: CsvDataProvider.java 6 2008-09-18 12:24:38Z simone.tripodi $
 */
public final class CsvDataProvider {

    /**
     * The {@link DataProvider} method's id used in this class.
     * Useful when declaring the {@link DataProvider} to refer the name
     */
    public final static String DATA_PROVIDER_ID = "csv-provider";

    private final static char PACKAGE_SEPARATOR_CHAR = '.';

    private final static char PATH_SEPARATOR_CHAR = '/';

    private final static String CLASSPATH_RESOURCE_PATTERN =
        "{0}.{1}.test-data.csv";

    private final static ConvertUtilsBean convertUtilsBean =
        new ConvertUtilsBean();

    static {
        DateConverter dateConverter = new DateConverter();
        dateConverter.setPatterns(new String[] {
                "yyyy",
                "yyyy-MM",
                "yyyy-MM-dd",
                "yyyy-MM-dd'T'HH",
                "yyyy-MM-dd'T'HH:mm",
                "yyyy-MM-dd'T'HH:mm:ss"
        });

        convertUtilsBean.register(dateConverter, Date.class);
    }

    private CsvDataProvider() {
        // this class can't be instantiated
    }

    /**
     * Builds a lazy data provider starting from a {@link Method}, that provides
     * useful informations such its arguments types, used to bind each CSV line
     * to proper types.
     *
     * @param method the method under test
     * @return an {@link Iterator} of method's arguments
     */
    @DataProvider(name = DATA_PROVIDER_ID)
    public static Iterator<Object[]> getDataProvider(Method method) {
        String className = method.getDeclaringClass().getName();
        String classPath =
            className.replace(PACKAGE_SEPARATOR_CHAR, PATH_SEPARATOR_CHAR);
        String classPathResource =
            MessageFormat.format(CLASSPATH_RESOURCE_PATTERN,
                    classPath,
                    method.getName());

        Class<?>[] types = method.getParameterTypes();
        Converter[] typeConverters = new Converter[types.length];
        for (int i = 0; i < types.length; i++) {
            typeConverters[i] = convertUtilsBean.lookup(types[i]);
        }

        return new CsvDataProviderIterator(classPathResource,
                types,
                typeConverters);
    }

}
