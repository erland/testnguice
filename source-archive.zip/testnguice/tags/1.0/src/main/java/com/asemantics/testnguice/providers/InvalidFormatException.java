/*
 *       Copyright (c) 2008 All rights reserved
 *               Asemantics S.r.l
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        Asemantics S.r.l."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by Asemantics S.r.l.
 *    the Semantic Web company, Rome, London, Leiden and its contributors.
 *
 * 5. Neither the name of the company nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package com.asemantics.testnguice.providers;

import java.util.Arrays;
import java.util.List;

/**
 * Thrown when a pased error occurs, such invalid CSV data format or
 * a specific line can't be binded into right method's type
 *
 * @author Simone Tripodi (simone.tripodi)
 * @version $Id: InvalidFormatException.java 2 2008-09-18 11:47:23Z simone.tripodi $
 */
public final class InvalidFormatException extends RuntimeException {

    private static final long serialVersionUID = -5474715685591060074L;

    /**
     * Constructor used when a parse error occurs analyzing CSV data.
     *
     * @param classPathResource the resource where data are loaded from
     * @param cause the parse error cause
     */
    public InvalidFormatException(String classPathResource, Throwable cause) {
        super("Classpath's resource ["
                + classPathResource
                + "] is an invalid format", cause);
    }

    /**
     * Constructor used when is not possible bind a line into right types
     *
     * @param classPathResource the resource where data are loaded from
     * @param lineNumber the line number where the conversion error occurred
     * @param types the original method's arguments types
     * @param line the line where the conversion error occurred
     */
    public InvalidFormatException(String classPathResource,
            int lineNumber,
            Class<?>[] types,
            List<String> line) {
        super("Line number ["
                + lineNumber
                + "] of classpath's resource ["
                + classPathResource
                + "] contains invalid data length: expected <"
                + types.length
                + "> "
                + Arrays.toString(types)
                +" but found <"
                + line.size()
                + "> "
                + line.toString());
    }

}
